# matchingproblems

This package can generate and solve single or multiple matching problem instances. 
