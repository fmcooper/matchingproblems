# __init__.py

from .solver import Solver