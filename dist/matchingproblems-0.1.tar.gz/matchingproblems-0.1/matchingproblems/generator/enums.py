from enum import Enum

class Matching_problem(Enum):
    HA = 1
    SM = 2
    HR = 3
    SPA = 4

